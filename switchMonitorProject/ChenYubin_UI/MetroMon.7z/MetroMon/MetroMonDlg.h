
// MetroMonDlg.h : ͷ�ļ�
//

#pragma once
#include "tchart1.h"
#include "afxwin.h"

#include "PrefDlg.h"

#include <vector>

struct LineFile{
	double Stats[8];
	CString CurFilePath;
	CString DefFilePath;
	char STATUS[256];
	char InsTime[256];

	int nCurrID;
	int isL2R;
};

const int RecdsCountPerQ = 10;

// CMetroMonDlg �Ի���
class CMetroMonDlg : public CDialogEx
{
// ����
public:
	CMetroMonDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_METROMON_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��

// ʵ��
protected:
	HICON m_hIcon;


	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CTchart1 m_chart;
	CTchart1 m_chartBar;

	CComboBox m_comboType;
	CComboBox m_comboChannel;
	CComboBox m_comboQ;

	CStatusBarCtrl m_statusBar;
	CMenu m_menu;

	std::vector<LineFile> m_Files;
	LineFile m_CurrLine;
	CRect m_rect;
	MYSQL m_sqlConn;

	CPrefDlg* m_pPreDlg;
	CImage m_img2enlarge;

	afx_msg void OnBnClickedOk();
	afx_msg void OnCbnSelchangeComboChnl();
	afx_msg void OnCbnSelchangeComboRecd();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg LRESULT OnStartUpTasks(WPARAM wParam, LPARAM lParam);

	void GetLast10AndPlot1(int lastSeq=0);
	void PlotOnTChart(int nCh=2);
	void PlotBars();
	int ConnMySQL();
	void DispImg();
	virtual void OnCancel();//����

	afx_msg void OnOptionsPreference();
	afx_msg void OnBnClickedButton1();
	afx_msg void OnDblclkPic1();
};


