#pragma once


// CPrefDlg �Ի���

class CPrefDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CPrefDlg)

public:
	CPrefDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CPrefDlg();

// �Ի�������
	enum { IDD = IDD_DLG_PREF };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	afx_msg LRESULT OnRecvFreshMsg(WPARAM wParam, LPARAM lParam);
	afx_msg void OnBnClickedBtnRefresh();

	DECLARE_MESSAGE_MAP()

public:
	void DispImg(CImage* p);
	

};
